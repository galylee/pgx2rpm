/*
 * src/backend/port/dynloader/aix.c
 *
 * Dummy file used for nothing at this point
 *
 * see aix.h
 */
