/*
 * src/backend/port/dynloader/sco.c
 *
 * Dummy file used for nothing at this point
 *
 * see sco.h
 */
