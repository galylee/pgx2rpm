/*
 * src/backend/port/dynloader/svr4.c
 *
 * Dummy file used for nothing at this point
 *
 * see svr4.h
 */
