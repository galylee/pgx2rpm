/* src/backend/port/dynloader/cygwin.c */

/* Dummy file used for nothing at this point; see cygwin.h */
